//
//  CDVMarket.h
//
// Created by Miguel Revetria miguel@xmartlabs.com on 2014-03-17.
// License Apache 2.0

#import <Foundation/Foundation.h>
#import <Cordova/CDVPlugin.h>

@interface CDVMarket : CDVPlugin

- (void)open:(CDVInvokedUrlCommand *)command;

@end