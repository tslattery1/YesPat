//
//  GoogleMapsBase.h
//  Google Maps SDK for iOS
//
//  Copyright 2017 Google Inc.
//
//  Usage of this SDK is subject to the Google Maps/Google Earth APIs Terms of
//  Service: https://developers.google.com/maps/terms
//

#import "GMSCompatabilityMacros.h"
#import "GMSCoordinateBounds.h"
#import "GMSDeprecationMacros.h"
